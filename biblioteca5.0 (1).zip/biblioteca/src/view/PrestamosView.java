package view;

import dao.PrestamoDAO;
import model.Prestamo;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import main.Conexion;

public class PrestamosView extends JFrame {
    
    public PrestamosView() throws SQLException {
        setTitle("Gestión de Préstamos");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        initUI();
        cargarPrestamos();
    }
    
    private void initUI() {
        // Configurar layout
        setLayout(new BorderLayout());
        
        // Crear tabla
        JTable tabla = new JTable();
        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane, BorderLayout.CENTER);
        
        // Panel de botones
        JPanel panelBotones = new JPanel();
        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(e -> {
            try {
                cargarPrestamos();
            } catch (SQLException ex) {
                Logger.getLogger(PrestamosView.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        panelBotones.add(btnActualizar);
        add(panelBotones, BorderLayout.SOUTH);
    }
    
    private void cargarPrestamos() throws SQLException {
    Connection conn = Conexion.establecerConexion();
    PrestamoDAO prestamoDAO = new PrestamoDAO(conn);
    List<Prestamo> prestamos = prestamoDAO.obtenerTodosPrestamos();

    String[] columnas = {"ID", "Usuario", "Material", "Fecha Préstamo", "Fecha Devolución", "Estado"};
    DefaultTableModel model = new DefaultTableModel(columnas, 0);

    for (Prestamo p : prestamos) {
        Object[] fila = {
            p.getIdPrestamo(),
            p.getUsuario().getIdUsuario(),                  
            p.getEjemplar().getIdEjemplar(),                 
            p.getFechaPrestamo(),
            p.getFechaDevolucionProgramada(),        
            p.getDevuelto().name()                   
        };
        model.addRow(fila);
    }

    ((JTable) ((JScrollPane) getContentPane().getComponent(0)).getViewport().getView()).setModel(model);
}
}
