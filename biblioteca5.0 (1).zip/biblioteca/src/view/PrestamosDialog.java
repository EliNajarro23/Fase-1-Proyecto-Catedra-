package view;

import dao.PrestamoDAO;
import model.Prestamo;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import main.Conexion;

public class PrestamosDialog extends JDialog {
    private JTable table;
    private JButton btnCerrar;
    private JButton btnActualizar;

    public PrestamosDialog(JFrame parent) {
        super(parent, "Gestión de Préstamos", true);
        setSize(900, 600);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());
        
        initComponents();
        cargarDatos();
    }

    private void initComponents() {
        // Tabla con scroll
        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
        
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(e -> cargarDatos());
        
        btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> dispose());
        
        panelBotones.add(btnActualizar);
        panelBotones.add(btnCerrar);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private void cargarDatos() {
    try (Connection conn = Conexion.establecerConexion()) {
        PrestamoDAO prestamoDAO = new PrestamoDAO(conn);
        List<Prestamo> prestamos = prestamoDAO.obtenerTodosPrestamos();
        
        String[] columnas = {"ID", "Usuario", "Material", "Fecha Préstamo", "Fecha Devolución", "Estado"};
        DefaultTableModel model = new DefaultTableModel(columnas, 0);
        
        for (Prestamo p : prestamos) {
            Object[] fila = {
                p.getIdPrestamo(),
                p.getUsuario().getIdUsuario(),
                p.getEjemplar().getIdEjemplar(),
                p.getFechaPrestamo(),
                p.getFechaDevolucionProgramada(),
                p.getDevuelto().name()
            };
            model.addRow(fila);
        }
        
        table.setModel(model);
        table.setAutoCreateRowSorter(true);
        
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this,
            "Error al cargar préstamos: " + ex.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    // Método para mostrar el diálogo
    public static void mostrar(JFrame parent) {
        PrestamosDialog dialog = new PrestamosDialog(parent);
        dialog.setVisible(true);
    }
}