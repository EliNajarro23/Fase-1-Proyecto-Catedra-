
package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import main.Conexion;
import model.Usuario;
import model.Usuario.EstadoCuenta;
import model.Usuario.Rol;
import view.MenuAdmin;
import view.MenuAlumno;
import view.MenuProfesor;


public class UsuarioDAO {
    
    private Conexion conexion;
    
    public UsuarioDAO(){
        this.conexion = new Conexion();                
    }
    
    
    public void validarUsuario(JTextField usuario, JPasswordField contrasena) {
    try {
        ResultSet rs = null;
        PreparedStatement ps = null;

        String sql = "SELECT * FROM Usuario WHERE Email = ? AND Contrasena = ?";
        ps = Conexion.establecerConexion().prepareStatement(sql);

        String contra = String.valueOf(contrasena.getPassword());
        ps.setString(1, usuario.getText());
        ps.setString(2, contra);

        rs = ps.executeQuery();

        if (rs.next()) {
            
            int id = rs.getInt("ID_Usuario");
            String nombre = rs.getString("nombre");
            String email = rs.getString("Email");
            String pass = rs.getString("Contrasena");

            
            Usuario.Rol rol = Usuario.Rol.valueOf(rs.getString("Rol").toUpperCase());
            Usuario.EstadoCuenta estado = Usuario.EstadoCuenta.valueOf(rs.getString("Estado_Cuenta").toUpperCase());

            
            Usuario usu = new Usuario(id, nombre, email, pass, rol, estado);

            
            if (usu.getEstadoCuenta() != Usuario.EstadoCuenta.ACTIVO) {
                JOptionPane.showMessageDialog(null, "Tu cuenta está suspendida, Contactate con el administrador.");
                return;
            }

            // Validamos el rol 
            switch (usu.getRol()) {
                 
                case ADMINISTRADOR:
                    String rolTexto = rs.getString("Rol");
                    new MenuAdmin(nombre,rolTexto).setVisible(true);
                    break;
                case PROFESOR:
                    String rolTextoP = rs.getString("Rol"); 
                    new MenuProfesor(nombre,rolTextoP).setVisible(true);
                    break;
                case ALUMNO:
                    String rolTextoA = rs.getString("Rol"); 
                    new MenuAlumno(nombre,rolTextoA).setVisible(true);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Rol no reconocido.");
            }
            
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(usuario);
            if (frame != null) {
            frame.dispose();
    }
        } else {
            JOptionPane.showMessageDialog(null, "Credenciales incorrectas.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "ERROR: " + e.toString());
    }
}
    
    // CREATE
    public void insertarUsuario(Connection conn, Usuario usuario) throws SQLException {
        String sql = "INSERT INTO Usuario (Nombre, Email, Contrasena, Rol, Estado_Cuenta) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getContrasena());
            ps.setString(4, usuario.getRol().name());
            ps.setString(5, usuario.getEstadoCuenta().name());
            ps.executeUpdate();
        }
    }

    // READ por ID
    public Usuario obtenerUsuarioPorId(Connection conn, int id) throws SQLException {
        String sql = "SELECT * FROM Usuario WHERE ID_Usuario = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearUsuario(rs);
                }
            }
        }
        return null;
    }

    // READ todos
    public List<Usuario> obtenerTodos() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM Usuario";
        try (Connection conn = conexion.establecerConexion();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                usuarios.add(mapearUsuario(rs));
            }
        }
        return usuarios;
    }

    // UPDATE
    public void actualizarUsuario(Connection conn, Usuario usuario) throws SQLException {
        String sql = "UPDATE Usuario SET Nombre=?, Email=?, Contrasena=?, Rol=?, Estado_Cuenta=? WHERE ID_Usuario=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getContrasena());
            ps.setString(4, usuario.getRol().name());
            ps.setString(5, usuario.getEstadoCuenta().name());
            ps.setInt(6, usuario.getIdUsuario());
            ps.executeUpdate();
        }
    }

    // DELETE
    public void eliminarUsuario(Connection conn, int id) throws SQLException {
        String sql = "DELETE FROM Usuario WHERE ID_Usuario=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
    
    public Object[][] getDatoTablaUsuario() throws SQLException{
        List<Usuario> usuarios = obtenerTodos();
        Object[][] datos = new Object[usuarios.size()][6];
        
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario u = usuarios.get(i);
            datos[i][0] = u.getIdUsuario();
            datos[i][1] = u.getNombre();
            datos[i][2] = u.getEmail();
            datos[i][3] = u.getContrasena();
            datos[i][4] = u.getRol();
            datos[i][5] = u.getEstadoCuenta();
        }
       return datos;
    }

    // Mapeo ResultSet -> Usuario
    private Usuario mapearUsuario(ResultSet rs) throws SQLException {
        int id = rs.getInt("ID_Usuario");
        String nombre = rs.getString("Nombre");
        String email = rs.getString("Email");
        String contrasena = rs.getString("Contrasena");
        Rol rol = Rol.valueOf(rs.getString("Rol").toUpperCase());
        EstadoCuenta estado = EstadoCuenta.valueOf(rs.getString("Estado_Cuenta").toUpperCase());

        return new Usuario(id, nombre, email, contrasena, rol, estado);
    }

    
}
