
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import main.Conexion;
import model.Material;
import model.Material.TipoMaterial;


public class MaterialDAO {
    private Connection conn;

    public MaterialDAO() {
        this.conn = Conexion.establecerConexion();
    }

   

    public int insertarMaterial(Material material) throws SQLException {
        String sql = "INSERT INTO Material (Titulo, Autor, Editorial, Anio, Tipo_Material, Ubicacion_Fisica, Cantidad_Ejemplares) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, material.getTitulo());
            ps.setString(2, material.getAutor());
            ps.setString(3, material.getEditorial());
            ps.setInt(4, material.getAnio());
            ps.setString(5, material.getTipoMaterial().name());
            ps.setString(6, material.getUbicacionFisica());
            ps.setInt(7, material.getCantidadEjemplares());

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1); 
            } else {
                throw new SQLException("No se pudo obtener el ID generado para el material.");
            }
        }
    }


    public Material obtenerMaterialPorId(int id) throws SQLException {
        String sql = "SELECT * FROM Material WHERE ID_Material = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                
                TipoMaterial tipoMaterial = TipoMaterial.valueOf(rs.getString("Tipo_Material"));
                
                return new Material(
                    rs.getInt("ID_Material"),
                    rs.getString("Titulo"),
                    rs.getString("Autor"),
                    rs.getString("Editorial"),
                    rs.getInt("Anio"),
                    tipoMaterial,
                    rs.getString("Ubicacion_Fisica"),
                    rs.getInt("Cantidad_Ejemplares")
                );
            }
        }
        return null;
    }
    
    public List<Material> obtenerTodos() throws SQLException {
        List<Material> material = new ArrayList<>();
        String sql = "SELECT * FROM Material";
        try (Connection conn = Conexion.establecerConexion();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                material.add(mapearMateriales(rs));
            }
        }
        return material;
    }
    
    public void actualizarMaterial(Material material) throws SQLException {
        String sql = "UPDATE Material SET Titulo = ?, Autor = ?, Editorial = ?, Anio = ?, Tipo_Material = ?, Ubicacion_Fisica = ?, Cantidad_Ejemplares = ? WHERE ID_Material = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, material.getTitulo());
            ps.setString(2, material.getAutor());
            ps.setString(3, material.getEditorial());
            ps.setInt(4, material.getAnio());
            ps.setString(5, material.getTipoMaterial().name());
            ps.setString(6, material.getUbicacionFisica());
            ps.setInt(7, material.getCantidadEjemplares());
            ps.setInt(8, material.getIdMaterial());

            ps.executeUpdate();
        }
    }

    
    public void eliminarMaterial(int id) throws SQLException {
        String sql = "DELETE FROM Material WHERE ID_Material = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    
    public List<Material> listarMaterialesPorTipo(TipoMaterial tipo) throws SQLException {
        List<Material> lista = new ArrayList<>();
        String sql = "SELECT * FROM Material WHERE Tipo_Material = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tipo.name());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Material mat = new Material(
                    rs.getInt("ID_Material"),
                    rs.getString("Titulo"),
                    rs.getString("Autor"),
                    rs.getString("Editorial"),
                    rs.getInt("Anio"),
                    tipo,
                    rs.getString("Ubicacion_Fisica"),
                    rs.getInt("Cantidad_Ejemplares")
                );
                lista.add(mat);
            }
        }
        return lista;
    }
    
    public Object[][] getDatoTablaMateriales() throws SQLException{
        List<Material> materiales = obtenerTodos();
        Object[][] datos = new Object[materiales.size()][8];
        
        for (int i = 0; i < materiales.size(); i++) {
            Material m = materiales.get(i);
            datos[i][0] = m.getIdMaterial();
            datos[i][1] = m.getTitulo();
            datos[i][2] = m.getAutor();
            datos[i][3] = m.getEditorial();
            datos[i][4] = m.getAnio();
            datos[i][5] = m.getTipoMaterial();
            datos[i][6] = m.getUbicacionFisica();
            datos[i][7] = m.getCantidadEjemplares();
        }
       return datos;
    }
    
    private Material mapearMateriales(ResultSet rs) throws SQLException {
        int id = rs.getInt("ID_Material");
        String titulo = rs.getString("Titulo");
        String autor = rs.getString("Autor");
        String editorial = rs.getString("Editorial");
        int anio = rs.getInt("Anio");
        TipoMaterial tm = TipoMaterial.valueOf(rs.getString("Tipo_Material").toUpperCase());
        String ubi = rs.getString("Ubicacion_Fisica");
        int canti = rs.getInt("Cantidad_Ejemplares");

        return new Material(id, titulo, autor, editorial, anio, tm, ubi, canti);
    }
    
    
}
