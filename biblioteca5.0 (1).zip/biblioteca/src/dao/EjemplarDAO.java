
package dao;

import model.Ejemplar;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import main.Conexion;
import model.Material;



public class EjemplarDAO {
    
    private Connection connection;
    private final MaterialDAO materialDAO;
    
    public EjemplarDAO(){
    this.connection = Conexion.establecerConexion();
     this.materialDAO = new MaterialDAO();
    }
    
    
    
    public Ejemplar obtenerPorId(int idEjemplar) throws SQLException {
        String sql = "SELECT * FROM Ejemplar WHERE ID_Ejemplar = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idEjemplar);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapearEjemplar(rs);
            }
        }
        return null;
    }

    // Listar todos los ejemplares
    public List<Ejemplar> listarTodos() throws SQLException {
        List<Ejemplar> ejemplares = new ArrayList<>();
        String sql = "SELECT * FROM Ejemplar";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                ejemplares.add(mapearEjemplar(rs));
            }
        }
        return ejemplares;
    }

    // Insertar un nuevo ejemplar
    public int insertarEjemplar(Ejemplar ejemplar) throws SQLException {
        String sql = "INSERT INTO Ejemplar (ID_Material, Codigo_Barra, Estado, Ubicacion_Fisica) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, ejemplar.getMaterial().getIdMaterial());
            stmt.setString(2, ejemplar.getCodigoBarra());
            stmt.setString(3, ejemplar.getEstado().name());
            stmt.setString(4, ejemplar.getUbicacionFisica());
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }
        }
        return -1;
    }

    // Actualizar un ejemplar
    public boolean actualizarEjemplar(Ejemplar ejemplar) throws SQLException {
        String sql = "UPDATE Ejemplar SET ID_Material = ?, Codigo_Barra = ?, Estado = ?, Ubicacion_Fisica = ? WHERE ID_Ejemplar = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, ejemplar.getMaterial().getIdMaterial());
            stmt.setString(2, ejemplar.getCodigoBarra());
            stmt.setString(3, ejemplar.getEstado().name());
            stmt.setString(4, ejemplar.getUbicacionFisica());
            stmt.setInt(5, ejemplar.getIdEjemplar());
            return stmt.executeUpdate() > 0;
        }
    }

    // Eliminar un ejemplar por ID
    public boolean eliminarEjemplar(int idEjemplar) throws SQLException {
        String sql = "DELETE FROM Ejemplar WHERE ID_Ejemplar = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idEjemplar);
            return stmt.executeUpdate() > 0;
        }
    }

    // Método de utilidad para mapear el ResultSet a un objeto Ejemplar
    private Ejemplar mapearEjemplar(ResultSet rs) throws SQLException {
        int idMaterial = rs.getInt("ID_Material");

    // Buscar el objeto Material completo desde la base de datos
    Material material = materialDAO.obtenerMaterialPorId(idMaterial);
    if (material == null) {
        throw new SQLException("No se encontró el Material con ID: " + idMaterial);
    }

    return new Ejemplar(
        rs.getInt("ID_Ejemplar"),
        material,
        rs.getString("Codigo_Barra"),
        Ejemplar.Estado.valueOf(rs.getString("Estado").toUpperCase()),
        rs.getString("Ubicacion_Fisica")
    );
    }
}
