
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import model.CD;
import model.Material;


public class CDDAO {
    
    private MaterialDAO materialDAO;
    private Connection connection;
    
    public CDDAO(Connection conn){
        this.connection = conn;
        this.materialDAO = new MaterialDAO();
    }
    
    public void insertarCD(CD cd) throws SQLException{
        try {
            connection.setAutoCommit(false);
            
            int materialId = materialDAO.insertarMaterial(cd);
            cd.setIdMaterial(materialId);
            
            String sql = "INSERT INTO CD (ID_Material, Genero, Duracion, Numero_Canciones) VALUES (?,?,?,?)";
            PreparedStatement stmcd = connection.prepareStatement(sql);
            stmcd.setInt(1, cd.getIdMaterial());
            stmcd.setString(2, cd.getGenero());
            LocalTime duracion = cd.getDuracion();  
            Time sqlTime = Time.valueOf(duracion);
            stmcd.setTime(3, sqlTime);
            stmcd.setInt(4, cd.getNumeroCanciones());
            stmcd.executeUpdate();
            
            connection.commit();
            
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        }finally{
            connection.setAutoCommit(true);
        }    
    }
    
    public void actualizarCD(CD cd) throws SQLException {
        try {
            connection.setAutoCommit(false);
            
            materialDAO.actualizarMaterial(cd);

            String sql = "UPDATE CD SET Genero = ?, Duracion = ?, Numero_Canciones = ? WHERE ID_Material = ?";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, cd.getGenero());
                ps.setTime(2, Time.valueOf(cd.getDuracion()));
                ps.setInt(3, cd.getNumeroCanciones());
                ps.setInt(4, cd.getIdMaterial());
                ps.executeUpdate();
            }

            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    public void eliminarCD(int id) throws SQLException {
        String sql = "DELETE FROM CD WHERE ID_Material = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }

        materialDAO.eliminarMaterial(id);
    }

    public List<CD> listarCDs() throws SQLException {
        List<CD> lista = new ArrayList<>();
        String sql = "SELECT * FROM CD INNER JOIN Material ON CD.ID_Material = Material.ID_Material";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                CD cd = new CD();
                cd.setIdMaterial(rs.getInt("ID_Material"));
                cd.setTitulo(rs.getString("Titulo"));
                cd.setAutor(rs.getString("Autor"));
                cd.setEditorial(rs.getString("Editorial"));
                cd.setAnio(rs.getInt("Anio"));
                cd.setTipoMaterial(Material.TipoMaterial.CD);
                cd.setUbicacionFisica(rs.getString("Ubicacion_Fisica"));
                cd.setCantidadEjemplares(rs.getInt("Cantidad_Ejemplares"));
                cd.setGenero(rs.getString("Genero"));
                cd.setDuracion(rs.getTime("Duracion").toLocalTime());
                cd.setNumeroCanciones(rs.getInt("Numero_Canciones"));
                lista.add(cd);
            }
        }
        return lista;
    }
    
    public void eliminarPorIdMaterial(int idMaterial) throws SQLException {
    String sql = "DELETE FROM CD WHERE ID_Material = ?";
    try (PreparedStatement ps = connection.prepareStatement(sql)) {
        ps.setInt(1, idMaterial);
        ps.executeUpdate();
    }
}
}
