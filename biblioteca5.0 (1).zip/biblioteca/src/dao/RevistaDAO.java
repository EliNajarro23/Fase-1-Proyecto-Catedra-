
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Material;
import model.Revista;


public class RevistaDAO {
    
    private MaterialDAO materialDAO;
    private Connection connection;
    
    public RevistaDAO(Connection conn){
    this.connection = conn;
    this.materialDAO = new MaterialDAO();
    }
    
    public void insertarRevista(Revista revista) throws SQLException{
        try {
            connection.setAutoCommit(false);
            
            int materialId = materialDAO.insertarMaterial(revista);
            revista.setIdMaterial(materialId);
            
            String sql = "INSERT INTO Revista (ID_Material, Numero_Edicion, Periodicidad) VALUES (?,?,?)";
            PreparedStatement stmrevista = connection.prepareStatement(sql);
            stmrevista.setInt(1, revista.getIdMaterial());
            stmrevista.setString(2, revista.getNumeroEdicion());
            stmrevista.setString(3, revista.getPeriodicidad().name());
            stmrevista.executeUpdate();
            
            connection.commit();
            
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        }finally{
            connection.setAutoCommit(true);
        }    
    }
    
    public void actualizarRevista(Revista revista) throws SQLException {
        try {
            connection.setAutoCommit(false);

            materialDAO.actualizarMaterial(revista);

            String sql = "UPDATE Revista SET Numero_Edicion = ?, Periodicidad = ? WHERE ID_Material = ?";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, revista.getNumeroEdicion());
                ps.setString(2, revista.getPeriodicidad().name());
                ps.setInt(3, revista.getIdMaterial());
                ps.executeUpdate();
            }

            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    public void eliminarRevista(int id) throws SQLException {
        String sql = "DELETE FROM Revista WHERE ID_Material = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }

        materialDAO.eliminarMaterial(id);
    }

    public List<Revista> listarRevistas() throws SQLException {
        List<Revista> lista = new ArrayList<>();
        String sql = "SELECT * FROM Revista INNER JOIN Material ON Revista.ID_Material = Material.ID_Material";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Revista revista = new Revista();
                revista.setIdMaterial(rs.getInt("ID_Material"));
                revista.setTitulo(rs.getString("Titulo"));
                revista.setAutor(rs.getString("Autor"));
                revista.setEditorial(rs.getString("Editorial"));
                revista.setAnio(rs.getInt("Anio"));
                revista.setTipoMaterial(Material.TipoMaterial.REVISTA);
                revista.setUbicacionFisica(rs.getString("Ubicacion_Fisica"));
                revista.setCantidadEjemplares(rs.getInt("Cantidad_Ejemplares"));
                revista.setNumeroEdicion(rs.getString("Numero_Edicion"));
                revista.setPeriodicidad(Revista.Periodicidad.valueOf(rs.getString("Periodicidad")));
                lista.add(revista);
            }
        }
        return lista;
    }
    
    public void eliminarPorIdMaterial(int idMaterial) throws SQLException {
    String sql = "DELETE FROM Revista WHERE ID_Material = ?";
    try (PreparedStatement ps = connection.prepareStatement(sql)) {
        ps.setInt(1, idMaterial);
        ps.executeUpdate();
    }
}
}
