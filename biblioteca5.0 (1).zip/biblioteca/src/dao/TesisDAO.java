
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Tesis;


public class TesisDAO {
    
    private MaterialDAO materialDAO;
    private Connection connection;
    
    public TesisDAO(Connection conn){
    this.connection = conn;
    this.materialDAO = new MaterialDAO();
    }
    
    public void insertarTesis(Tesis tesis) throws SQLException{
        try {
            connection.setAutoCommit(false);
            
            int materialId = materialDAO.insertarMaterial(tesis);
            tesis.setIdMaterial(materialId);
            
            String sql = "INSERT INTO Tesis (ID_Material, Universidad, Carrera) VALUES (?,?,?)";
            PreparedStatement stmtesis = connection.prepareStatement(sql);
            stmtesis.setInt(1, tesis.getIdMaterial());
            stmtesis.setString(2, tesis.getUniversidad());
            stmtesis.setString(3, tesis.getCarrera());
            stmtesis.executeUpdate();
            
            connection.commit();
            
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        }finally{
            connection.setAutoCommit(true);
        }    
    }
    
     public List<Tesis> listarTodos() throws SQLException {
        List<Tesis> lista = new ArrayList<>();
        String sql = "SELECT * FROM Tesis";
        PreparedStatement stm = connection.prepareStatement(sql);
        ResultSet rs = stm.executeQuery();

        while (rs.next()) {
            Tesis tesis = new Tesis();
            tesis.setIdMaterial(rs.getInt("ID_Material"));
            tesis.setUniversidad(rs.getString("Universidad"));
            tesis.setCarrera(rs.getString("Carrera"));
            lista.add(tesis);
        }
        return lista;
    }
     public void actualizarTesis(Tesis tesis) throws SQLException {
        try {
            connection.setAutoCommit(false);
            materialDAO.actualizarMaterial(tesis);

            String sql = "UPDATE Tesis SET Universidad = ?, Carrera = ? WHERE ID_Material = ?";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, tesis.getUniversidad());
            stm.setString(2, tesis.getCarrera());
            stm.setInt(3, tesis.getIdMaterial());
            stm.executeUpdate();

            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    // Eliminar
    public void eliminarTesis(int idMaterial) throws SQLException {
        try {
            connection.setAutoCommit(false);

            String sql = "DELETE FROM Tesis WHERE ID_Material = ?";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setInt(1, idMaterial);
            stm.executeUpdate();

            materialDAO.eliminarMaterial(idMaterial);

            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(true);
        }
    }
    
    public void eliminarPorIdMaterial(int idMaterial) throws SQLException {
    String sql = "DELETE FROM Tesis WHERE ID_Material = ?";
    try (PreparedStatement ps = connection.prepareStatement(sql)) {
        ps.setInt(1, idMaterial);
        ps.executeUpdate();
    }
}
}
