package dao;

import model.Prestamo;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.Ejemplar;
import model.Prestamo.Devuelto;
import model.Usuario;

public class PrestamoDAO {
    private final Connection connection;

    public PrestamoDAO(Connection connection) {
        this.connection = connection;
    }

    public int insertarPrestamo(Prestamo prestamo) throws SQLException {
        String sql = "INSERT INTO Prestamo (ID_Usuario, ID_Ejemplar, Fecha_Prestamo, Fecha_Devolucion_Programada, Devuelto) " +
                     "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, prestamo.getUsuario().getIdUsuario());
            stmt.setInt(2, prestamo.getEjemplar().getIdEjemplar());
            stmt.setDate(3, Date.valueOf(prestamo.getFechaPrestamo()));
            stmt.setDate(4, Date.valueOf(prestamo.getFechaDevolucionProgramada()));
            stmt.setString(5, prestamo.getDevuelto().name());  // "SI" o "NO"

            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("No se pudo insertar el préstamo.");
            }

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                } else {
                    throw new SQLException("No se generó ID para el préstamo.");
                }
            }
        }
    }

    public List<Prestamo> obtenerTodosPrestamos() throws SQLException {
        List<Prestamo> prestamos = new ArrayList<>();
        String sql = "SELECT * FROM Prestamo";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Prestamo p = mapearPrestamo(rs);
                prestamos.add(p);
            }
        }

        return prestamos;
    }

    public Prestamo obtenerPrestamoPorId(int id) throws SQLException {
        String sql = "SELECT * FROM Prestamo WHERE ID_Prestamo = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapearPrestamo(rs);
            }
        }
        return null;
    }

    private Prestamo mapearPrestamo(ResultSet rs) throws SQLException {
        int id = rs.getInt("ID_Prestamo");
        int idUsuario = rs.getInt("ID_Usuario");
        int idEjemplar = rs.getInt("ID_Ejemplar");
        LocalDate fechaPrestamo = rs.getDate("Fecha_Prestamo").toLocalDate();
        LocalDate fechaDevolucion = rs.getDate("Fecha_Devolucion_Programada").toLocalDate();
        Devuelto devuelto = Devuelto.valueOf(rs.getString("Devuelto").toUpperCase());

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario usuario = usuarioDAO.obtenerUsuarioPorId(connection, idUsuario); // O buscar usuario completo si es necesario
        EjemplarDAO ejemplarDAO = new EjemplarDAO();
        Ejemplar ejemplar =  ejemplarDAO.obtenerPorId(idEjemplar); // O buscar ejemplar completo si es necesario

        return new Prestamo(id, usuario, ejemplar, fechaPrestamo, fechaDevolucion, devuelto);
    }
}