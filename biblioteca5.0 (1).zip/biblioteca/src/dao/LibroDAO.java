
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Libro;
import model.Material.TipoMaterial;

public class LibroDAO {
    
      
      private MaterialDAO materialDAO;
        private Connection connection;
      
    public LibroDAO(Connection conn) {
        this.connection = conn;
        this.materialDAO = new MaterialDAO();
    }

    public void insertarLibro(Libro libro) throws SQLException {
        try {
            connection.setAutoCommit(false);
            
            int materialId = materialDAO.insertarMaterial(libro);
            libro.setIdMaterial(materialId);
            
            String sql = "INSERT INTO Libro (ID_Material, ISBN, Numero_Paginas) VALUES (?, ?, ?)";
            PreparedStatement stmlibro = connection.prepareStatement(sql);
            stmlibro.setInt(1, libro.getIdMaterial());
            stmlibro.setString(2, libro.getIsbn());
            stmlibro.setInt(3, libro.getNumeroPaginas());
            stmlibro.executeUpdate();
            
            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally{
            connection.setAutoCommit(true);
        }        
    }
    
     public void actualizarLibro(Libro libro) throws SQLException {
        try {
            connection.setAutoCommit(false);

            materialDAO.actualizarMaterial(libro);

            String sql = "UPDATE Libro SET ISBN = ?, Numero_Paginas = ? WHERE ID_Material = ?";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, libro.getIsbn());
                ps.setInt(2, libro.getNumeroPaginas());
                ps.setInt(3, libro.getIdMaterial());
                ps.executeUpdate();
            }

            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    public void eliminarLibro(int id) throws SQLException {
        String sql = "DELETE FROM Libro WHERE ID_Material = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }

        materialDAO.eliminarMaterial(id);
    }

    public List<Libro> listarLibros() throws SQLException {
        List<Libro> lista = new ArrayList<>();
        String sql = "SELECT * FROM Libro INNER JOIN Material ON Libro.ID_Material = Material.ID_Material";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Libro libro = new Libro();
                libro.setIdMaterial(rs.getInt("ID_Material"));
                libro.setTitulo(rs.getString("Titulo"));
                libro.setAutor(rs.getString("Autor"));
                libro.setEditorial(rs.getString("Editorial"));
                libro.setAnio(rs.getInt("Anio"));
                libro.setTipoMaterial(TipoMaterial.LIBRO);
                libro.setUbicacionFisica(rs.getString("Ubicacion_Fisica"));
                libro.setCantidadEjemplares(rs.getInt("Cantidad_Ejemplares"));
                libro.setIsbn(rs.getString("ISBN"));
                libro.setNumeroPaginas(rs.getInt("Numero_Paginas"));
                lista.add(libro);
            }
        }
        return lista;
    }
    
    public void eliminarPorIdMaterial(int idMaterial) throws SQLException {
    String sql = "DELETE FROM Libro WHERE ID_Material = ?";
    try (PreparedStatement ps = connection.prepareStatement(sql)) {
        ps.setInt(1, idMaterial);
        ps.executeUpdate();
    }
}
}
   

