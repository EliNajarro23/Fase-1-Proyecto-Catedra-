
package main;

import java.sql.*;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class Conexion {
    
    private static Connection conectar = null;
    boolean mensajeMostrado = false;
    private static final String user = "root";
    private static final String passW = "root";
    private static final String bd = "bibliotecadonbosco";
    private static final String ip = "localhost";
    private static final String puerto = "3306";
    private static final String cade = "jdbc:mysql://"+ip+":"+puerto+"/"+bd;
    
    public static Connection establecerConexion(){
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conectar = DriverManager.getConnection(cade, user, passW);
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No se conectó a la base de datos, error:" +e.toString());
        }
        
        return conectar;
    }
}
