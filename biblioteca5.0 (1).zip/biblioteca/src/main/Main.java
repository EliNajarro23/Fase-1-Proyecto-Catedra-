package main;

import view.AgregarLibro;
import view.LoginForm;
import view.MenuAdmin;
import view.VerEjemplares;
import view.VerUsuarios;

public class Main {
   
    public static void main(String[] args) {
       
        Conexion objConexion = new Conexion();
        objConexion.establecerConexion();    
        
        LoginForm forml = new LoginForm();
        forml.setVisible(true);
        
        //new VerUsuarios().setVisible(true);
        
        //new AgregarLibro().setVisible(true);
        
       // new VerEjemplares().setVisible(true);
       
       
    }
}
