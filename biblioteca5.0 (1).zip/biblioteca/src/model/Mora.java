
package model;

public class Mora {      
    
    private int idMora;
    private Prestamo prestamo;
    private double monto;
    private int diasAtraso;

    //Constructor datos
    public Mora(int idMora, Prestamo prestamo, double monto, int diasAtraso) {
        this.idMora = idMora;
        this.prestamo = prestamo;
        this.monto = monto;
        this.diasAtraso = diasAtraso;
    }

    // Getters & setters
    public int getIdMora() {
        return idMora;
    }

    public void setIdMora(int idMora) {
        this.idMora = idMora;
    }

    public Prestamo getPrestamo() {
        return prestamo;
    }

    public void setPrestamo(Prestamo prestamo) {
        this.prestamo = prestamo;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public int getDiasAtraso() {
        return diasAtraso;
    }

    public void setDiasAtraso(int diasAtraso) {
        this.diasAtraso = diasAtraso;
    }  
  
}
