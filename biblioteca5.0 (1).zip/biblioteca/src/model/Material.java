
package model;

public class Material {
   
    private int idMaterial;
    private String titulo;
    private String autor;
    private String editorial;
    private int anio;
    private TipoMaterial tipoMaterial;
    private String ubicacionFisica;
    private int cantidadEjemplares;
    
    public enum TipoMaterial {
    LIBRO, REVISTA, CD, TESIS
    }
    
    //Constructor
    public Material(){
    }
    
    //Connstructor datos
    public Material(int idMaterial, String titulo, String autor, String editorial, int anio, TipoMaterial tipoMaterial, String ubicacionFisica, int cantidadEjemplares){
        this.idMaterial = idMaterial;
        this.titulo = titulo;
        this.autor = autor;
        this.editorial = editorial;
        this.anio = anio;
        this.tipoMaterial = tipoMaterial;
        this.ubicacionFisica = ubicacionFisica;
        this.cantidadEjemplares = cantidadEjemplares;
        
    }   
         
    // Getters & Setters
    public int getIdMaterial() {
        return idMaterial;
    }

    public void setIdMaterial(int idMaterial) {
        this.idMaterial = idMaterial;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public TipoMaterial getTipoMaterial() {
        return tipoMaterial;
    }

    public void setTipoMaterial(TipoMaterial tipoMaterial) {
        this.tipoMaterial = tipoMaterial;
    }

    public String getUbicacionFisica() {
        return ubicacionFisica;
    }

    public void setUbicacionFisica(String ubicacionFisica) {
        this.ubicacionFisica = ubicacionFisica;
    }

    public int getCantidadEjemplares() {
        return cantidadEjemplares;
    }

    public void setCantidadEjemplares(int cantidadEjemplares) {
        this.cantidadEjemplares = cantidadEjemplares;
    }
    
    
}
