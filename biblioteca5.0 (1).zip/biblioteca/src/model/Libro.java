
package model;

public class Libro extends Material {
    
    private String isbn;
    private int numeroPaginas;
    
    public Libro(){
    }
    
    //Constructor datos
    public Libro(int idMaterial, String titulo, String autor, String editorial,int anio, String isbn, int numeroPaginas, String ubicacionFisica, int cantidadEjemplares) {
        super(idMaterial, titulo, autor, editorial, anio, TipoMaterial.LIBRO, ubicacionFisica, cantidadEjemplares);
        this.isbn = isbn;
        this.numeroPaginas = numeroPaginas;
    }

    
    // Getters & setters
    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }
}
