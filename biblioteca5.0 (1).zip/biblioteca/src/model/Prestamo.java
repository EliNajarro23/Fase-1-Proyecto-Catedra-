package model;

import java.time.LocalDate;

public class Prestamo {
    
    private int idPrestamo;
    private Usuario usuario;
    private Ejemplar ejemplar;
    private LocalDate fechaPrestamo;
    private LocalDate fechaDevolucionProgramada;
    private Devuelto devuelto;
    
    public enum Devuelto {
    SI, NO
    }

    public Prestamo(int idPrestamo, Usuario usuario, Ejemplar ejemplar,
                    LocalDate fechaPrestamo, LocalDate fechaDevolucionProgramada, Devuelto devuelto) {
        this.idPrestamo = idPrestamo;
        this.usuario = usuario;
        this.ejemplar = ejemplar;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucionProgramada = fechaDevolucionProgramada;
        this.devuelto = devuelto;
    }

    // Getters y setters
    public int getIdPrestamo() {
        return idPrestamo;
    }

    public void setIdPrestamo(int idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Ejemplar getEjemplar() {
        return ejemplar;
    }

    public void setEjemplar(Ejemplar ejemplar) {
        this.ejemplar = ejemplar;
    }

    public LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(LocalDate fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public LocalDate getFechaDevolucionProgramada() {
        return fechaDevolucionProgramada;
    }

    public void setFechaDevolucionProgramada(LocalDate fechaDevolucionProgramada) {
        this.fechaDevolucionProgramada = fechaDevolucionProgramada;
    }

    public Devuelto getDevuelto() {
        return devuelto;
    }

    public void setDevuelto(Devuelto devuelto) {
        this.devuelto = devuelto;
    }
}
