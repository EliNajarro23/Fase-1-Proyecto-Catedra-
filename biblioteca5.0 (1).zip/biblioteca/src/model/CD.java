
package model;

import java.time.LocalTime;

public class CD extends Material{
    
    private String genero;
    private LocalTime duracion;
    private int numeroCanciones;
    
    //Constructor datos
    public CD(int idMaterial, String titulo, String autor, String editorial, int anio,String ubicacionFisica, int cantidadEjemplares, String genero, LocalTime duracion, int numeroCanciones) {
        super(idMaterial, titulo, autor, editorial, anio, TipoMaterial.CD, ubicacionFisica, cantidadEjemplares);
        this.genero = genero;
        this.duracion = duracion;
        this.numeroCanciones = numeroCanciones;
    }

    public CD() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Getters & setters
    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public LocalTime getDuracion() {
        return duracion;
    }

    public void setDuracion(LocalTime duracion) {
        this.duracion = duracion;
    }

    public int getNumeroCanciones() {
        return numeroCanciones;
    }

    public void setNumeroCanciones(int numeroCanciones) {
        this.numeroCanciones = numeroCanciones;
    }
}
    
    

