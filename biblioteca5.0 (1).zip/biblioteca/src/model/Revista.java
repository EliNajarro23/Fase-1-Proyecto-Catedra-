
package model;

public class Revista extends Material {
    
    private String numeroEdicion;
    private Periodicidad periodicidad;

    public Revista() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public enum Periodicidad {
    SEMANAL, MENSUAL, TRIMESTRAL, ANUAL
    }
    
    //Constructor datos
    public Revista(int idMaterial, String titulo, String autor, String editorial, int anio,String ubicacionFisica, int cantidadEjemplares,String numeroEdicion, Periodicidad periodicidad) {
        super(idMaterial, titulo, autor, editorial, anio, TipoMaterial.REVISTA, ubicacionFisica, cantidadEjemplares);
        this.numeroEdicion = numeroEdicion;
        this.periodicidad = periodicidad;
    }

    // Getters & setters
    public String getNumeroEdicion() {
        return numeroEdicion;
    }

    public void setNumeroEdicion(String numeroEdicion) {
        this.numeroEdicion = numeroEdicion;
    }

    public Periodicidad getPeriodicidad() {
        return periodicidad;
    }

    public void setPeriodicidad(Periodicidad periodicidad) {
        this.periodicidad = periodicidad;
    }
}
