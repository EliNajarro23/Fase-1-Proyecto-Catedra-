
package model;

public class Ejemplar {
    
    private int idEjemplar;
    private Material material;
    private String codigoBarra;
    private Estado estado; 
    private String ubicacionFisica;

    
    
    public enum Estado {
        DISPONIBLE, PRESTADO
    }
    
    //Constructor datos
    public Ejemplar(int idEjemplar, Material material, String codigoBarra, Estado estado, String ubicacionFisica) {
        this.idEjemplar = idEjemplar;
        this.material = material;
        this.codigoBarra = codigoBarra;
        this.estado = estado;
        this.ubicacionFisica = ubicacionFisica;
    }

    // Getters & setters
    public int getIdEjemplar() {
        return idEjemplar;
    }

    public void setIdEjemplar(int idEjemplar) {
        this.idEjemplar = idEjemplar;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public String getCodigoBarra() {
        return codigoBarra;
    }

    public void setCodigoBarra(String codigoBarra) {
        this.codigoBarra = codigoBarra;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public String getUbicacionFisica() {
        return ubicacionFisica;
    }

    public void setUbicacionFisica(String ubicacionFisica) {
        this.ubicacionFisica = ubicacionFisica;
    }

    
    
}
