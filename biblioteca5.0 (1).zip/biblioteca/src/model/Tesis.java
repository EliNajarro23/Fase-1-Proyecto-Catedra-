
package model;

public class Tesis extends Material{
    
    private String universidad;
    private String carrera;

    //Constructor datos
    public Tesis(int idMaterial, String titulo, String autor, String editorial, int anio, String ubicacionFisica, int cantidadEjemplares,String universidad, String carrera) {
        super(idMaterial, titulo, autor, editorial, anio, TipoMaterial.TESIS, ubicacionFisica, cantidadEjemplares);
        this.universidad = universidad;
        this.carrera = carrera;
    }

    public Tesis() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Getters & setters
    public String getUniversidad() {
        return universidad;
    }

    public void setUniversidad(String universidad) {
        this.universidad = universidad;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }
}
